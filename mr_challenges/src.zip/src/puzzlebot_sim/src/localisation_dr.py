#!/usr/bin/env python

""" Implement a node that calculates the odometry for the puzzlebot robot.
"""

import numpy as np
import rospy, tf
# import tf2_ros
# from tf import transformations as trf
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped, PoseStamped, Twist, Point, Quaternion, PoseWithCovariance, TwistWithCovariance
from sensor_msgs.msg import JointState
from std_msgs.msg import Float32
from std_srvs.srv import Empty, EmptyResponse

R, L = 0.05, 0.18
FS = 60
T = 1.0/FS
STD_DEV = 0.001
Kl = 0.5
Kr = 0.5

class LocalisationNode():
    def __init__(self):

        rospy.init_node("localisation_deadreckoning")

        # Subscribe to the wheel velocity topics
        rospy.Subscriber("/wl", Float32, self._wl_callback)
        rospy.Subscriber("/wr", Float32, self._wr_callback)
        self.wl = 0
        self.wr = 0

        # Subscribe to the twist topic
        rospy.Subscriber("/cmd_vel", Twist, self._vel_callback)
        self.v = 0
        self.w = 0
        self.u = np.array([self.v, self.w])
        
        # Publish to the odometry topic
        self.pOdom = rospy.Publisher("/odom", Odometry, queue_size=10)
        self.odom = Odometry()

        # Publish to the 
        self.pPose = rospy.Publisher('/pose', PoseStamped, queue_size=10)
        self.model_pose = PoseStamped()

        # Publish to the joint states topic ()
        self.pJS = rospy.Publisher('/joint_states', JointState, queue_size=10)
        self.js = JointState()

        # Service for reset state values
        ser = rospy.Service("/reset", Empty, self._ser_callback)

        # States of the mobile robot
        self.x = 0.0
        self.y = 0.0
        self.q = 0.0
        self.model_state = np.array([self.x, self.y, self.q])

        # Initial covariance matrix
        self.sigma = np.zeros((3, 3))
        
        # Matrix tunned according to the test of mini challenge 1
        

        # Matrix
        self.del_w = 0.5*R*T * np.array([[np.cos(self.q), np.cos(self.q)],
                                         [np.sin(self.q), np.sin(self.q)],
                                         [2/L, -2/L]])
               
        # For broadcasting transform from base_link to odom 
        self.tb = tf.TransformBroadcaster()
        
        # Solo se usa el mensaje de odometria, tenemos que esta madre flateen para una dimension eos a listo y una transpuesta
        self.rate = rospy.Rate(FS)
        
    def _wl_callback(self, msg):
        self.wl = msg.data
        
    def _wr_callback(self, msg):
        self.wr = msg.data

    def _vel_callback(self, msg):
        self.v = msg.linear.x
        self.w = msg.angular.z

    def _ser_callback(self, req):
        self.x = 0.0
        self.y = 0.0
        self.q = 0.0
        return EmptyResponse()
                
    def main(self):

        t0 = rospy.Time.now()

        while not rospy.is_shutdown():

            self.model_pose.pose.position = Point(self.x, self.y, 0)
            qRota = tf.transformations.quaternion_from_euler(0, 0, self.q)
            self.model_pose.pose.orientation = Quaternion(qRota[0], qRota[1], qRota[2], qRota[3])

            cTime = rospy.Time.now()
            self.model_pose.header.stamp = cTime
            self.model_pose.header.frame_id = "base_link"
            self.pPose.publish(self.model_pose)
            self.tb.sendTransform([self.x, self.y, 0], qRota, cTime, "base_link", "map")
 
            self.js.name = ['right_wheel_joint', 'left_wheel_joint']
            t = cTime - t0
            self.js.position = [self.wr*t.to_sec(), self.wl*t.to_sec()]
            self.js.header.stamp = cTime
            self.pJS.publish(self.js)

            self.tunner = np.array([[Kr*np.abs(self.wr), 0],
                              [0, Kl*np.abs(self.wl)]])

            # Nondeterministic error matrix 
            print("------del_w-----")
            print(self.del_w)
            print("------tunner-----")
            print(self.tunner)
            print("------del_w.T-----")
            print(self.del_w.T)
            Q = np.dot(np.dot(self.del_w, self.tunner), self.del_w.T)
            print("------Q-----")
            print(Q)
            # Linear model Jacobian of the robot           
            H = np.array([[1.0, 0.0, -T*self.v*np.sin(self.q)], 
                         [0.0, 1.0, T*self.v*np.cos(self.q)],
                         [0.0, 0.0, 1.0]])
            print("------H-----")
            print(H)
            self.sigma = np.dot(np.dot(H, self.sigma), H.T) + Q
            cov = np.zeros((6, 6))
            cov[:3, :3] = self.sigma
            cov[3:, 3:] = np.zeros((3, 3))
            cov[3:, :3] = np.zeros((3, 3))
            cov[:3, 3:] = np.zeros((3, 3))

            cov[0, 0], cov[0, 1], cov[1, 1] = np.ix_([0, 1, 2], [0, 1, 2])
            cov[0, 5], cov[1, 5], cov[1, 6], cov[2, 6] = np.ix_([0, 1, 2], [3, 4, 5])
            cov[5, 5], cov[5, 6], cov[6, 6] = np.ix_([3, 4, 5], [3, 4, 5])

            cov = cov.flatten()
            print(cov)

            self.x += T*self.v*np.cos(self.q)
            self.y += T*self.v*np.sin(self.q)
            self.q += T*self.w

            self.odom.header.stamp = cTime
            self.odom.header.frame_id = "base_link"
            self.odom.pose.covariance = cov # REVISAR ESTO
            #self.odom.pose.position = self.model_pose
            self.odom.pose.pose.position  = Point(self.x, self.y, 0)
            self.odom.pose.pose.orientation = Quaternion(qRota[0], qRota[1], qRota[2], qRota[3])
            #self.odom.twist = self.model_twist # REVISAR ESTO
            self.pOdom.publish(self.odom)

            # A = 
            # B = np.array([[T*np.cos(self.q), 0.0], 
            #               [T*np.sin(self.q), 0.0],
            #               [0.0, T]])
            
            # u = np.array([self.v, self.w])
            # self.model_state = np.dot(A, self.model_state) + np.dot(B, u)

            # self.model_state[0] += np.random.normal(0.0, STD_DEV)
            # self.model_state[1] += np.random.normal(0.0, STD_DEV)
            # self.model_state[2] += np.random.normal(0.0, STD_DEV)

            # self.x = self.model_state[0]
            # self.y = self.model_state[1]
            # self.q = self.model_state[2]

            self.rate.sleep()
                    
if __name__ == '__main__':

    try:
        aux = LocalisationNode()
        aux.main()

    except rospy.ROSInterruptException:
        pass